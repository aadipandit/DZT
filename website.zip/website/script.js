// JavaScript code to enhance the website experience
// Add more dynamic effects or interactivity if needed

document.addEventListener('DOMContentLoaded', function() {
    console.log("Welcome to DropZoneTourney!");
});
